﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using magazinn.Pages;
using magazinn.Classes;

namespace magazinn.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageCompany.xaml
    /// </summary>
    public partial class PageCompany : Page
    {
        public PageCompany()
        {
            InitializeComponent();
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Company.ToList();
            var listCompany = MagazinEntities.GetContext().Company.Select(x=>x.CompanyName).Distinct().ToList();
            CmbFiltrCompany.Items.Add("Все компании");
            foreach(string company in listCompany)
            {
                CmbFiltrCompany.Items.Add(company);
            }
        }
        private void btnEdit_Click(object sender, RoutedEventArgs e)
        //Редактирование пользователей
        {
            ClassFrame.frmObj.Navigate(new PageAddCompany((sender as Button).DataContext as Company));
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        // Добавление пользователей
        {
            ClassFrame.frmObj.Navigate(new PageAddCompany(null)/*((Person)DGridUsers.SelectedItem)*/);
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            //Удаление нескольких пользователей
            var personForRemoving = DGridUsers.SelectedItems.Cast<Company>().ToList();
            if (MessageBox.Show($"Удалить {personForRemoving.Count()} пользователей?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    MagazinEntities.GetContext().Company.RemoveRange(personForRemoving);
                    MagazinEntities.GetContext().SaveChanges();
                    MessageBox.Show("Данные удалены");
                    DGridUsers.ItemsSource = MagazinEntities.GetContext().Company.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void Page_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        {//Динамиеское отображение добавленных или изменённых данных
            if (Visibility == Visibility.Visible)
            {
                MagazinEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                DGridUsers.ItemsSource = MagazinEntities.GetContext().Company.ToList();
            }
        }

        private void BtnResetAll_Click(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Company.ToList();
        }

        private void RbUp_Checked(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Company.OrderBy(x => x.CompanyName).ToList();
        }

        private void RbDown_Checked(object sender, RoutedEventArgs e)
        {
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Company.OrderByDescending(x => x.CompanyName).ToList();
        }



        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            DGridUsers.ItemsSource = MagazinEntities.GetContext().Company.Where(x => x.CompanyName.ToLower().Contains(TxtSearch.Text.ToLower())).ToList();
        }

        private void CmbFiltrCompany_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string companyname = CmbFiltrCompany.SelectedValue.ToString();
            if (companyname != "Все компании")
                DGridUsers.ItemsSource = MagazinEntities.GetContext().Company.Where(x => x.CompanyName == companyname).ToList();
            else
                DGridUsers.ItemsSource = MagazinEntities.GetContext().Company.ToList();


        }

        private void DGridUsers_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }


        //private void BtnToList_Click(object sender, RoutedEventArgs e)
        //{
        //    ClassFrame.frmObj.Navigate(new PageListStudent());
        //}
    }
}
